<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Version_137 extends CI_Migration
{
    function __construct()
    {
        parent::__construct();
    }

    public function up()
    {
        // Nothing to do here only to update database version number
    }
}
