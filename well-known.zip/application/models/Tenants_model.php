<?php

use app\services\AbstractKanban;

defined('BASEPATH') or exit('No direct script access allowed');

class Tenants_model extends App_Model
{
    public function __construct()
    {
        parent::__construct();
    }


    /**
     * Get lead by given email
     *
     * @since 2.8.0
     *
     * @param  string $email
     *
     * @return \strClass|null
     */
    public function get_pro(){
        $this->db->order_by('id', 'asc');
        $this->db->select('*');
        return $this->db->get('tblprojects')->result();
    }





}
