<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper" style="min-height: 704.75px;">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="_buttons tw-mb-2 sm:tw-mb-4">
                     <a href="https://crm.dukesterling.com/admin/addtenant" class="btn btn-primary pull-left display-block mright5"><i class="fa-regular fa-plus tw-mr-1"></i> New Tenant</a><div class="clearfix"></div>
                </div>

                <div class="panel_s tw-mt-2 sm:tw-mt-4">
                    <div class="panel-body">

                        <div class="row mbot15">
                            <div class="col-md-12">
                                <h4 class="tw-mt-0 tw-font-semibold tw-text-lg tw-flex tw-items-center">
                                   <i class="fa fa-users" style=" margin-right: 5px; "></i> <span>Tenants</span></h4> </div>
                        </div>
                        <hr class="hr-panel-separator">
                        <div class="panel-table-full">
                            <div class="">
                                <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row"></div>
                                    <div id="DataTables_Table_0_processing" class="dataTables_processing panel panel-default" style="display: none;">
                                        <div class="dt-loader"></div>
                                    </div>
                                    <div class="table-responsive">
                                        <table data-last-order-identifier="projects" data-default-order="" class="table table-projects number-index-1 dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info">
                                            <thead>
                                                <tr role="row">
                                                    <th class="tenants" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="# activate to sort column ascending">#</th>
                                                    <th class="tenants" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Customer activate to sort column ascending">Name</th>
                                                    <th class="tenants" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Tags activate to sort column ascending">Gender</th>
                                                    <th class="tenants" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Tags activate to sort column ascending">Phone</th>
                                                    <th class="tenants" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Start Date activate to sort column ascending">Tenant Type</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($projectss as $dis) { ?>
                                                <tr class="has-row-options odd">
                                                    
                                                    <td><a href="#"><?php echo $dis->id ?></a></td>
                                                    <td><?php echo $dis->name ?></td>
                                                    <td>Male</td>
                                                    <td><a href="#">01672540210</a></td>
                                                    <td>business</td>
                                                </tr>
                                                 <?php }?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="row" style="display:none;">
                                        <div class="col-md-4">
                                            <div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite">Showing 1 to 1 of 1 entries</div>
                                        </div>
                                        <div class="col-md-8 dataTables_paging">
                                            <div id="colvis"></div>
                                            <div id="" class="dt-page-jump"></div>
                                            <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                                <ul class="pagination">
                                                    <li class="paginate_button previous disabled" id="DataTables_Table_0_previous"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="0" tabindex="0">Previous</a></li>
                                                    <li class="paginate_button active"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="1" tabindex="0">1</a></li>
                                                    <li class="paginate_button next disabled" id="DataTables_Table_0_next"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="2" tabindex="0">Next</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php init_tail(); ?>