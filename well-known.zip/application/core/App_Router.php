<?php

defined('BASEPATH') or exit('No direct script access allowed');

/* load the MX_Router class */
require APPPATH . 'third_party/MX/Router.php';

class App_Router extends MX_Router
{
}
