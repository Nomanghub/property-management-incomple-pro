<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_302 extends CI_Migration
{
    public function up()
    {
    }
}